from bib.uteis import log_term, sleep

def init_ui():
    log_term("[UI] Init UI")
    sleep(1)
    log_term("[UI] UI Ready")