from bib.uteis import log_term, sleep
from core.state_manager import StateManager, state_type

def start_action_VoicePrompt(state_manager: StateManager):
    log_term("[ACTION] Init VoicePrompt")
    sleep(30)
    log_term("[ACTION] End VoicePrompt")

    state_manager.set_state(state_type.READY)
    
    